
import os
import subprocess

def install(package):
    """Install a Python package using pip."""
    subprocess.check_call([os.sys.executable, "-m", "pip", "install", package])

# Step 1: Install dependencies for Logistic Regression (Baseline Model)
# Libraries used: scikit-learn for Logistic Regression and evaluation metrics
print("Installing dependencies for Logistic Regression...")
install("scikit-learn")  # Machine learning library for regression models and metrics

# Step 2: Install dependencies for Gradient Boosting
# Libraries used: lightgbm (alternative to XGBoost for Gradient Boosting)
print("Installing dependencies for Gradient Boosting...")
install("lightgbm")  # Gradient Boosting library for regression and classification

# Step 3: Install dependencies for Multi-Task Neural Network
# Libraries used: PyTorch for defining and training the neural network
print("Installing dependencies for Multi-Task Neural Network...")
install("torch")  # PyTorch core library for building neural networks
install("torchvision")  # PyTorch library for computer vision tools (not directly needed here but common in setups)
install("torchaudio")  # PyTorch library for audio processing (optional, included for standard installation)

# Step 4: Additional common dependencies
# Libraries used across all models for data handling and preprocessing
print("Installing additional common dependencies...")
install("pandas")  # Data manipulation library
install("numpy")  # Numerical computing library
install("matplotlib")  # Data visualization library (for plotting model results)
install("joblib")  # Serialization library for saving trained models

# Step 5: Final message
print("\nAll dependencies are installed. You can now run the models in VSCode!")
