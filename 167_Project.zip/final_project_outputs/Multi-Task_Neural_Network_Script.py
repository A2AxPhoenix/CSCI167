
# Multi-Task Neural Network Model Script
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import pandas as pd

# Load and preprocess the dataset
data_path = "processed_cleaned_unified_vg_data.csv"  # Replace with your file path
data = pd.read_csv(data_path)
time_series_data = data.groupby("Year")[["NA_Sales", "EU_Sales", "JP_Sales", "Other_Sales", "Global_Sales"]].mean().reset_index()
scaler = MinMaxScaler()
scaled_time_series_data = scaler.fit_transform(time_series_data.iloc[:, 1:])
X_time_series = time_series_data[["Year"]].values
y_time_series = scaled_time_series_data

X_train, X_test, y_train, y_test = train_test_split(X_time_series, y_time_series, test_size=0.2, random_state=42, shuffle=False)
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

# Define the Multi-Task Neural Network
class MultiTaskNN(nn.Module):
    def __init__(self):
        super(MultiTaskNN, self).__init__()
        self.shared_layer_1 = nn.Linear(1, 64)
        self.shared_layer_2 = nn.Linear(64, 32)
        self.activation = nn.ReLU()
        self.na_sales_head = nn.Linear(32, 1)
        self.eu_sales_head = nn.Linear(32, 1)
        self.jp_sales_head = nn.Linear(32, 1)
        self.other_sales_head = nn.Linear(32, 1)
        self.global_sales_head = nn.Linear(32, 1)

    def forward(self, x):
        x = self.activation(self.shared_layer_1(x))
        x = self.activation(self.shared_layer_2(x))
        return {
            "NA_Sales": self.na_sales_head(x),
            "EU_Sales": self.eu_sales_head(x),
            "JP_Sales": self.jp_sales_head(x),
            "Other_Sales": self.other_sales_head(x),
            "Global_Sales": self.global_sales_head(x)
        }

# Instantiate the model
model = MultiTaskNN()
print("Multi-Task Neural Network defined. Ready for training.")
