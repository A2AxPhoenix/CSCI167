
# Logistic Regression Model Script
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# Load the cleaned dataset
data_path = "processed_cleaned_unified_vg_data.csv"  # Replace with your file path
data = pd.read_csv(data_path)

# Prepare features and target for classification
X = data.drop(columns=["Global_Sales", "Genre_Success", "Name", "Rank", "Platform", "Genre", "Publisher"], errors="ignore")
y = data["Genre_Success"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train Logistic Regression
log_reg = LogisticRegression(max_iter=1000, random_state=42, class_weight="balanced")
log_reg.fit(X_train, y_train)

# Evaluate the model
y_pred = log_reg.predict(X_test)
results = {
    "Accuracy": accuracy_score(y_test, y_pred),
    "Precision": precision_score(y_test, y_pred),
    "Recall": recall_score(y_test, y_pred),
    "F1 Score": f1_score(y_test, y_pred),
    "AUC": roc_auc_score(y_test, log_reg.predict_proba(X_test)[:, 1]),
}

print("Logistic Regression Results:", results)
