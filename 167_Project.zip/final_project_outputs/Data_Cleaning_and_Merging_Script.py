
import pandas as pd
import numpy as np

# Step 1: Load the datasets
# Replace these file paths with your local paths
vgchartz_2024_path = "vgchartz-2024.csv"
vgsales_path = "vgsales.csv"
vgsales2_path = "vgsales 2.csv"

vgchartz_2024 = pd.read_csv(vgchartz_2024_path)
vgsales = pd.read_csv(vgsales_path)
vgsales2 = pd.read_csv(vgsales2_path)

# Step 2: Clean `vgchartz-2024.csv`
# Rename and drop columns to align with the other datasets
vgchartz_2024 = vgchartz_2024.rename(
    columns={
        "title": "Name",
        "console": "Platform",
        "genre": "Genre",
        "publisher": "Publisher",
        "total_sales": "Global_Sales",
        "na_sales": "NA_Sales",
        "jp_sales": "JP_Sales",
        "other_sales": "Other_Sales",
        "release_date": "Year",
    }
)
vgchartz_2024 = vgchartz_2024.drop(
    columns=["img", "developer", "critic_score", "pal_sales", "last_update"], errors="ignore"
)
# Extract year from release_date
vgchartz_2024["Year"] = vgchartz_2024["Year"].str[:4].astype(float)

# Step 3: Align and merge datasets
# Ensure all datasets have consistent columns
vgsales = vgsales.rename(columns={"Platform": "Platform", "Year_of_Release": "Year"})
vgsales2 = vgsales2.rename(columns={"Platform": "Platform", "Year_of_Release": "Year"})

# Merge all datasets
merged_data = pd.concat([vgchartz_2024, vgsales, vgsales2], ignore_index=True)

# Step 4: Handle missing values
# Drop rows with missing `Year` or `Global_Sales`
merged_data = merged_data.dropna(subset=["Year", "Global_Sales"])

# Step 5: Feature Engineering
# Encode categorical features
merged_data["Platform_Encoded"] = merged_data["Platform"].astype("category").cat.codes
merged_data["Genre_Encoded"] = merged_data["Genre"].astype("category").cat.codes
merged_data["Publisher_Encoded"] = merged_data["Publisher"].astype("category").cat.codes

# Normalize numerical sales data using log transform
for column in ["NA_Sales", "EU_Sales", "JP_Sales", "Other_Sales", "Global_Sales"]:
    merged_data[column] = np.log1p(merged_data[column])

# Step 6: Add a `Genre_Success` column
# Adjust thresholds to reduce by 15%
def define_genre_success(row):
    if row["Year"] < 2000:
        return 1 if np.expm1(row["Global_Sales"]) > 0.425 else 0
    elif 2000 <= row["Year"] <= 2010:
        return 1 if np.expm1(row["Global_Sales"]) > 0.85 else 0
    elif 2010 < row["Year"] <= 2020:
        return 1 if np.expm1(row["Global_Sales"]) > 1.7 else 0
    else:
        return 1 if np.expm1(row["Global_Sales"]) > 2.55 else 0

# Apply the updated thresholds
merged_data["Genre_Success"] = merged_data.apply(define_genre_success, axis=1)

# Save the updated unified dataset
processed_cleaned_path = "processed_cleaned_unified_vg_data.csv"
merged_data.to_csv(processed_cleaned_path, index=False)

print(f"Processed unified dataset with updated Genre_Success thresholds saved to {processed_cleaned_path}")
